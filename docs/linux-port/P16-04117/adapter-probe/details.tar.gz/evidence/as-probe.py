import subprocess,os,time,pathlib,json,sys,hashlib
root=pathlib.Path('/out');which=sys.argv[1];dst=root/(which+'.json');log=root/(which+'.stderr');started=time.monotonic();profile=[]
with log.open('w') as errors:
 child=subprocess.Popen(['/runtime/bin/python3.12','-I','/safety/worker-as'+which+'.py','/runtime','/input/source.png','["eng"]',str(dst)],stdout=subprocess.PIPE,stderr=errors)
 while child.poll() is None and time.monotonic()-started<150:
  try:
   lines=pathlib.Path(f'/proc/{child.pid}/status').read_text().splitlines();profile.append({k:int(v.strip().split()[0]) for row in lines if ':' in row for k,v in [row.split(':',1)] if k in ['VmPeak','VmSize','VmHWM','VmRSS']})
  except FileNotFoundError:pass
  time.sleep(.01)
 if child.poll() is None:child.terminate()
 out,_=child.communicate(timeout=5)
result=dict(limitASGiB=float(which),exit=child.returncode,seconds=time.monotonic()-started,stdout=out.decode(errors='replace'),stderr=log.read_text()[-4096:],documentExists=dst.exists(),peaksKiB={k:max((p.get(k,0) for p in profile),default=0) for k in ['VmPeak','VmSize','VmHWM','VmRSS']});(root/(which+'-profile.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
