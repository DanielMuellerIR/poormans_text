import pathlib,subprocess,json,hashlib,sys,runpy,math
from PIL import Image
root=pathlib.Path('/work/dpi');root.mkdir(exist_ok=True);old='/base/raster.py';new='/new/raster.py'
def sha(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def info(p):
 im=Image.open(p);return dict(sha256=sha(p),size=im.size,mode=im.mode,metadata=im.info,pixelRGBA_SHA256=hashlib.sha256(im.convert('RGBA').tobytes()).hexdigest())
source=Image.open('/standalone/source.png');source.save(root/'nodpi.png');Image.new('RGB',(5001,4000),'white').save(root/'large.png',dpi=(300,300));source.save(root/'anisotropic.png',dpi=(300,150));source.save(root/'zero.png',dpi=(0,0));small=Image.new('RGB',(120,80),'white');exif=small.getexif();exif[274]=6;small.save(root/'rotation.jpg',exif=exif,dpi=(300,300));sources={'original':pathlib.Path('/standalone/source.png'),'natural':pathlib.Path('/standalone/natural132.png'),'nodpi':root/'nodpi.png','large':root/'large.png','rotation':root/'rotation.jpg','anisotropic':root/'anisotropic.png','zero':root/'zero.png'};result={}
def run(name,script,source,mode='frames',preserve=False):
 dst=root/name;dst.mkdir(exist_ok=True);args=['python3',script,mode,str(source)]+(['--index','1'] if mode=='preview' else [])+(['--preserve-resolution'] if preserve else []);r=subprocess.run(args,cwd=dst,capture_output=True,text=True,timeout=15);return dict(exit=r.returncode,stdout=r.stdout,stderr=r.stderr,frame=info(dst/('preview.png' if mode=='preview' else 'frame-1.png')) if (dst/('preview.png' if mode=='preview' else 'frame-1.png')).exists() else None)
for name,source in sources.items():
 value={'source':info(source),'standardOld':run(name+'-old',old,source),'standardNew':run(name+'-new',new,source),'preserved':run(name+'-preserve',new,source,preserve=True)}
 assert value['standardOld']==value['standardNew'],name
 if name in ['anisotropic','zero']:assert value['preserved']['exit']==65 and value['preserved']['frame'] is None
 else:assert value['preserved']['exit']==0
 if name in ['original','natural','nodpi']:
  assert value['source']['pixelRGBA_SHA256']==value['preserved']['frame']['pixelRGBA_SHA256']
 result[name]=value
oldPreview=run('preview-old',old,sources['original'],'preview');newPreview=run('preview-new',new,sources['original'],'preview');assert oldPreview==newPreview;result['previewByteUnchanged']=True
api=runpy.run_path(new);hardening={}
for label,dpi in [('nan',(math.nan,math.nan)),('infinite',(math.inf,math.inf)),('negative',(-1,-1)),('tooHigh',(10001,10001)),('boolean',(True,True))]:
 im=Image.new('RGB',(10,10));im.info['dpi']=dpi
 try:api['source_resolution'](im);hardening[label]=False
 except ValueError:hardening[label]=True
assert all(hardening.values());result['hardening']=hardening
(root/'result.json').write_text(json.dumps(result,indent=2,default=str)+'\n');print(json.dumps({'cases':list(sources),'standardByteUnchanged':True,'previewByteUnchanged':True,'hardening':hardening}))
