import pathlib,subprocess,json,hashlib
from PIL import Image
root=pathlib.Path('/work/pdf-resolution');root.mkdir(exist_ok=True)
def run(name,helper,mode,source,preserve=False):
 dst=root/name;dst.mkdir(exist_ok=True)
 args=['python3',helper,mode,source]
 if mode=='extract':args += [str(dst),'[0]','always']+(['--preserve-resolution'] if preserve else [])
 if mode=='preview':args += ['1']
 p=subprocess.run(args,cwd=dst,capture_output=True,text=True,timeout=20)
 files={str(f.relative_to(dst)):hashlib.sha256(f.read_bytes()).hexdigest() for f in dst.rglob('*') if f.is_file()}
 return dict(exit=p.returncode,stdout=p.stdout,stderr=p.stderr,files=files)
r={}
for name in ['scanned','mixed']:
 source='/work/'+name+'.pdf';old=run(name+'-old','/base/poppler.py','extract',source);new=run(name+'-new','/new/poppler.py','extract',source);assert old==new
 oldp=run(name+'-preview-old','/base/poppler.py','preview',source);newp=run(name+'-preview-new','/new/poppler.py','preview',source);assert oldp==newp
 preserved=run(name+'-physical','/new/poppler.py','extract',source,True);assert preserved['exit']==0
 frame=root/(name+'-physical')/'page-1-ocr.png';im=Image.open(frame);page=json.loads((frame.parent/'page-1.json').read_text());r[name]=dict(standardByteUnchanged=True,previewByteUnchanged=True,preserved=preserved,rasterSize=im.size,dpi=im.info.get('dpi'),pageSize=[page['width'],page['height']],expectedDPI=[im.width/page['width']*72,im.height/page['height']*72])
 assert all(abs(x-y)<=0.012701 for x,y in zip(r[name]['dpi'],r[name]['expectedDPI']))
 oldv=run(name+'-validate-old','/base/poppler.py','validate-attachment',source);newv=run(name+'-validate-new','/new/poppler.py','validate-attachment',source);assert oldv==newv
 r[name]['attachmentValidationUnchanged']=True
(root/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:{x:v[x] for x in ['standardByteUnchanged','previewByteUnchanged','attachmentValidationUnchanged','dpi','expectedDPI']} for k,v in r.items()}))
