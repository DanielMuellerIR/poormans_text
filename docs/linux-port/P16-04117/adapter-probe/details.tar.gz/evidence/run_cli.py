import subprocess,pathlib,os,time,json,sys,hashlib,ctypes,select,struct,shutil
root=pathlib.Path('/work');source=root/sys.argv[1];destination=root/sys.argv[2]
command=['/src/.build/x86_64-unknown-linux-gnu/debug/poormans-text','--json','--ocr-method','structured','--ocr-language','en','--pdf-ocr','always','--output',str(destination),'--',str(source)]
started=time.monotonic();child=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE);captured=None;watchFD=-1;watchPath=None;observerError=None;cancelSent=False;peaks={}
while child.poll() is None and time.monotonic()-started<170:
 for item in pathlib.Path('/proc').iterdir():
  if not item.name.isdigit():continue
  try:
   args=(item/'cmdline').read_bytes().split(b'\0')
   if args and args[0].endswith(b'/bin/python3.12') and b'/pmt/input/1' in args:
    captured={'pid':int(item.name),'args':[a.decode(errors='replace') for a in args if a],'limits':(item/'limits').read_text(),'workerPIDNamespace':os.readlink(item/'ns/pid'),'workerNetworkNamespace':os.readlink(item/'ns/net'),'cliPIDNamespace':os.readlink(f'/proc/{child.pid}/ns/pid'),'cliNetworkNamespace':os.readlink(f'/proc/{child.pid}/ns/net')}
    for line in (item/'status').read_text().splitlines():
     if ':' in line:
      key,value=line.split(':',1)
      if key in ['VmPeak','VmSize','VmHWM','VmRSS']:peaks[key]=max(peaks.get(key,0),int(value.strip().split()[0]))

    if watchFD<0:
     try:
      watchPath=f'/proc/{item.name}/root/pmt/work-scope';libc=ctypes.CDLL(None,use_errno=True);watchFD=libc.inotify_init1(0x800|0x80000)
      if watchFD<0 or libc.inotify_add_watch(watchFD,os.fsencode(watchPath),0x8)<0:raise OSError(ctypes.get_errno(),'inotify watch failed')
      shutil.copyfile(watchPath+'/source.png',root/(sys.argv[2]+'-raster.png'))
     except (OSError,PermissionError) as error:observerError=str(error)

  except (FileNotFoundError,ProcessLookupError,PermissionError):pass
 if watchFD>=0 and select.select([watchFD],[],[],.005)[0]:
  data=os.read(watchFD,65536);offset=0
  while offset+16<=len(data):
   wd,mask,cookie,length=struct.unpack_from('iIII',data,offset);name=data[offset+16:offset+16+length].split(b'\0')[0];offset+=16+length
   if name in (b'document.json',b'verified-document.json'):
    try:
     with open(watchPath+'/'+name.decode(),'rb') as handle:raw=handle.read(8*1024**2+1)
     if len(raw)<=8*1024**2:(root/(sys.argv[2]+'-model.json')).write_bytes(raw)
    except (OSError,PermissionError) as error:observerError=str(error)
 if len(sys.argv)>3 and sys.argv[3]=='cancel' and captured and not cancelSent:
  for task in pathlib.Path('/proc').iterdir():
   if task.name.isdigit():
    try:
     if (task/'comm').read_text().strip()=='tesseract':child.terminate();cancelSent=True;break
    except (FileNotFoundError,ProcessLookupError,PermissionError):pass
 time.sleep(.005)
if child.poll() is None:child.terminate()
stdout,stderr=child.communicate(timeout=10)
(root/(sys.argv[2]+'-raw.json')).write_bytes(stdout);(root/(sys.argv[2]+'-stderr.txt')).write_bytes(stderr)
r={'exit':child.returncode,'seconds':time.monotonic()-started,'worker':captured,'observerError':observerError,'cancelSent':cancelSent,'workerPeaksKiB':peaks,'sourceSHA256':hashlib.file_digest(source.open('rb'),'sha256').hexdigest()};(root/(sys.argv[2]+'-process.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'exit':r['exit'],'seconds':r['seconds'],'capturedWorker':captured is not None}));sys.exit(child.returncode)
