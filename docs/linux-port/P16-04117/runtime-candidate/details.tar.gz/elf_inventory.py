import subprocess,re,json
from pathlib import Path
r=Path(__file__).resolve().parent;root=r/'candidate';records=[];versions=set();needed=set()
for f in root.rglob('*'):
 if not f.is_file() or f.is_symlink():continue
 with f.open('rb') as s:
  if s.read(4)!=b'\x7fELF':continue
 p=subprocess.run(['readelf','-Vd',str(f)],capture_output=True,text=True,timeout=5)
 v=set(re.findall(r'\bGLIBC_(\d+\.\d+(?:\.\d+)?)\b',p.stdout));versions|=v;n=re.findall(r'\(NEEDED\).*?\[([^]]+)\]',p.stdout);needed.update(n)
 records.append({'path':str(f.relative_to(root)),'glibcMax':max(v,key=lambda x:tuple(map(int,x.split('.')))) if v else None,'needed':n})
(r/'elf-inventory.json').write_text(json.dumps({'highestGLIBC':max(versions,key=lambda x:tuple(map(int,x.split('.')))),'neededSONAMEs':sorted(needed),'files':records},indent=2)+'\n');print(len(records),'ELFs maxGLIBC',max(versions,key=lambda x:tuple(map(int,x.split('.')))))
