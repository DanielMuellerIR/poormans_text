import urllib.request,json,hashlib
from pathlib import Path
r=Path(__file__).resolve().parent;j=json.loads((r/'python-release.json').read_text());asset=next(x for x in j['assets'] if x['name']=='cpython-3.12.16+20261026-x86_64-unknown-linux-gnu-pgo+lto-full.tar.zst');target=r/'downloads/python-full.tar.zst';count=0;h=hashlib.sha256()
if not target.exists():
 with urllib.request.urlopen(asset['browser_download_url'],timeout=90) as response,target.open('xb') as out:
  while data:=response.read(1024**2):count+=len(data);assert count<=asset['size'];h.update(data);out.write(data)
 assert count==asset['size'] and 'sha256:'+h.hexdigest()==asset['digest']
records=[dict(source=asset['browser_download_url'],bytes=asset['size'],sha256=asset['digest'].split(':')[1],path=str(target.name))]
for repo,rev in [('docling-project/docling-models','fc0f2d45e2218ea24bce5045f58a389aed16dc23'),('docling-project/docling-layout-heron','8f39ad3c0b4c58e9c2d2c84a38465abf757272d8')]:
 for name in ['README.md','LICENSE']:
  url=f'https://huggingface.co/{repo}/resolve/{rev}/{name}'
  try:data=urllib.request.urlopen(url,timeout=30).read()
  except Exception as e:print(url,type(e).__name__,e);continue
  target=r/'primary-license-evidence'/repo.replace('/','--')/name;target.parent.mkdir(exist_ok=True);target.write_bytes(data);records.append(dict(source=url,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),path=str(target.relative_to(r))))
(r/'extra-downloads.json').write_text(json.dumps(records,indent=2)+'\n');print(records)
