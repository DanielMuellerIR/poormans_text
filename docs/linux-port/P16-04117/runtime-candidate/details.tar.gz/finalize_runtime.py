import argparse,hashlib,json,shutil,stat
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--pins',type=Path,required=True);args=parser.parse_args();r=Path(__file__).resolve().parent;root=r/'candidate'
for p in list(root.rglob('__pycache__')):
 if p.is_dir():shutil.rmtree(p)
links=[]
for p in root.rglob('*'):
 if p.is_symlink():
  target=p.resolve();assert target.is_relative_to(root) and target.is_file();data=p.read_bytes();mode=target.stat().st_mode;p.unlink();p.write_bytes(data);p.chmod(stat.S_IMODE(mode));links.append(str(p.relative_to(root)))
for name in ['wheels.json','models.json','requirements-resolved.txt']:shutil.copyfile(args.pins/name,root/'notices'/name)
shutil.copyfile(r/'libcrypt-downloads.json',root/'notices/libcrypt-sources.json')
for name in ['libxcrypt_4.4.36.orig.tar.xz','libxcrypt_4.4.36-4build1.debian.tar.xz','libxcrypt_4.4.36-4build1.dsc']:shutil.copyfile(r/'downloads'/name,root/'notices'/name)
files={}
for p in sorted(root.rglob('*')):
 if p.is_file() and p.name!='runtime-manifest.json':files[str(p.relative_to(root))]={'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest(),'byteCount':p.stat().st_size}
manifest={'schemaVersion':1,'backend':'docling','qualifiedAdapterVersion':1,'runtimeKind':'pmt-docling-cpu','pythonVersion':'3.12.16','doclingVersion':'2.147.0','doclingIBMModelsVersion':'4.0.4','platform':'x86_64-linux-gnu','minimumGLIBC':'2.38','externalTools':['/usr/bin/tesseract with eng traineddata'],'files':files}
(root/'runtime-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
for p in root.rglob('*'):
 if p.is_file():p.chmod((p.stat().st_mode&0o111)|0o444)
 elif p.is_dir():p.chmod(0o555)
root.chmod(0o555)
summary={'manifestSHA256':hashlib.file_digest((root/'runtime-manifest.json').open('rb'),'sha256').hexdigest(),'files':len(files),'byteCount':sum(x['byteCount'] for x in files.values()),'dereferencedInternalSymlinks':len(links),'symlinksRemaining':len([p for p in root.rglob('*') if p.is_symlink()])}
(r/'candidate-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(summary)
