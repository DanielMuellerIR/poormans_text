#!/usr/bin/env python3
"""JSON-Modellprobe, nur fest vorgegebene lokale Modelle, kein Markdownexport."""
import os
for key,value in {'HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','HF_HUB_DISABLE_TELEMETRY':'1','OMP_NUM_THREADS':'2','MKL_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2','PYTHONDONTWRITEBYTECODE':'1'}.items():os.environ[key]=value
import sys,json,time,resource,hashlib
from pathlib import Path
import torch
from docling.datamodel.accelerator_options import AcceleratorDevice,AcceleratorOptions
from docling.datamodel.base_models import InputFormat
from docling.datamodel.pipeline_options import PdfPipelineOptions,LayoutObjectDetectionOptions,TableStructureOptions,TableFormerMode,TesseractCliOcrOptions,OcrMode
from docling.document_converter import DocumentConverter,ImageFormatOption
source,output,runtime=map(Path,sys.argv[1:]);started=time.monotonic();before=hashlib.file_digest(source.open('rb'),'sha256').hexdigest();torch.set_num_threads(2);torch.set_num_interop_threads(1)
layout=LayoutObjectDetectionOptions.from_preset('layout_heron_default');layout.model_spec=layout.model_spec.model_copy(update={'revision':'8f39ad3c0b4c58e9c2d2c84a38465abf757272d8'})
options=PdfPipelineOptions(artifacts_path=runtime/'models');options.accelerator_options=AcceleratorOptions(device=AcceleratorDevice.CPU,num_threads=2);options.layout_options=layout;options.do_table_structure=True;options.table_structure_options=TableStructureOptions(mode=TableFormerMode.ACCURATE,do_cell_matching=True);options.do_ocr=True;options.enable_remote_services=False;options.ocr_options=TesseractCliOcrOptions(lang=['eng'],mode=OcrMode.FULL_PAGE)
converter=DocumentConverter(allowed_formats=[InputFormat.IMAGE],format_options={InputFormat.IMAGE:ImageFormatOption(pipeline_options=options)})
result=converter.convert(source,max_num_pages=1,max_file_size=10*1024**2);document=result.document.export_to_dict();output.write_text(json.dumps(document,ensure_ascii=False)+'\n')
print(json.dumps({'status':str(result.status),'python':sys.version,'prefix':sys.prefix,'seconds':time.monotonic()-started,'sourceUnchanged':before==hashlib.file_digest(source.open('rb'),'sha256').hexdigest(),'tableCount':len(document.get('tables',[])),'maxRSSKiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'memoryPeakBytes':int(Path('/sys/fs/cgroup/memory.peak').read_text()),'jsonBytes':output.stat().st_size}),flush=True)
