#!/usr/bin/env python3
"""Belegt Originalmetadaten und tatsächlich mitgelieferte Lizenztexte aller Wheels."""
from pathlib import Path
from email.parser import BytesParser
import hashlib,json,re,zipfile
root=Path(__file__).resolve().parent;cache=root/'downloads';out=root/'license-evidence';out.mkdir(exist_ok=True);records=[]
for wheel in sorted(cache.glob('*.whl')):
 with zipfile.ZipFile(wheel) as z:
  meta=[n for n in z.namelist() if n.endswith('.dist-info/METADATA') and n.count('/')==1];assert len(meta)==1
  b=z.read(meta[0]);m=BytesParser().parsebytes(b);name=m['Name'];package=out/name;package.mkdir(exist_ok=True);(package/'METADATA').write_bytes(b)
  entries=[];recognized=set()
  for n in z.namelist():
   if n.endswith('/') or not ('/licenses/' in n.lower() or re.search(r'(^|/)(licen[sc]e[^/]*|copying[^/]*|notice[^/]*|authors[^/]*)$',n,re.I)):continue
   data=z.read(n);text=data.decode('utf-8','replace');target=package/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
   for label,pattern in [('Apache-2.0',r'Apache License[\s,]+Version 2\.0|Apache License, Version 2\.0'),('MIT',r'Permission is hereby granted, free of charge'),('BSD-3-Clause',r'Neither the name|neither the name'),('BSD-2-Clause',r'Redistributions in binary form must reproduce'),('PSF',r'PYTHON SOFTWARE FOUNDATION LICENSE'),('MPL-2.0',r'Mozilla Public License.*2\.0'),('LGPL',r'GNU LESSER GENERAL PUBLIC LICENSE'),('GPL',r'GNU GENERAL PUBLIC LICENSE')]:
    if re.search(pattern,text,re.S):recognized.add(label)
   entries.append({'wheelPath':n,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'savedPath':str(target.relative_to(out))})
  direct=[m.get('License-Expression'),m.get('License')];classifiers=[v for v in m.get_all('Classifier',[]) if v.startswith('License ::')]
  records.append({'name':name,'version':m['Version'],'wheel':wheel.name,'metadataLicenseExpression':direct[0],'metadataLicense':direct[1],'licenseClassifiers':classifiers,'declaredLicenseFiles':m.get_all('License-File',[]),'projectURLs':m.get_all('Project-URL',[]),'homePage':m.get('Home-page'),'actualLicenseFiles':entries,'textPatternsNotLegalConclusion':sorted(recognized),'evidenceStatus':'LICENSE_TEXT_PRESENT' if entries else ('METADATA_ONLY' if any(direct) or classifiers else 'OPEN_NO_LICENSE_EVIDENCE')})
(root/'licenses.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n');print(len(records),'packages');print([(x['name'],x['evidenceStatus']) for x in records if x['evidenceStatus']!='LICENSE_TEXT_PRESENT']);print('wheels without license scalar/expression but with text',sum(x['evidenceStatus']=='LICENSE_TEXT_PRESENT' and not x['metadataLicenseExpression'] and not x['metadataLicense'] for x in records))
