import subprocess,json,sys
from pathlib import Path
root=Path(sys.argv[1]);records=[]
for f in root.rglob('*'):
 if not f.is_file() or f.is_symlink():continue
 with f.open('rb') as s:
  if s.read(4)!=b'\x7fELF':continue
 r=subprocess.run(['ldd',str(f)],capture_output=True,text=True,timeout=5)
 absent=[line.strip() for line in r.stdout.splitlines() if 'not found' in line]
 if absent:records.append({'path':str(f.relative_to(root)),'missing':absent})
print(json.dumps({'pythonHost':subprocess.run(['python3','--version'],capture_output=True,text=True).stdout,'glibc':subprocess.run(['ldd','--version'],capture_output=True,text=True).stdout.splitlines()[0],'unresolved':records},indent=2))
