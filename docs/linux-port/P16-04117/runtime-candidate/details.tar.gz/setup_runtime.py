#!/usr/bin/env python3
"""Bewusster begrenzter Download fester Quellen und offline relocierbare Installation."""
import argparse,hashlib,json,os,subprocess,tarfile,urllib.request,urllib.parse,zipfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--pins',type=Path,required=True);p.add_argument('--root',type=Path,required=True);a=p.parse_args();root=a.root;cache=root/'downloads';cache.mkdir(exist_ok=True);runtime=root/'candidate';runtime.mkdir(exist_ok=True)
wheels=json.loads((a.pins/'wheels.json').read_text());models=json.loads((a.pins/'models.json').read_text());python=json.loads((root/'python-pin.json').read_text());records=[]
items=[('python.tar.gz',python)]+[(urllib.parse.unquote(urllib.parse.urlparse(x['source']).path.rsplit('/',1)[1]),x) for x in wheels]+[(x['repo'].replace('/','--')+'/'+x['file'],dict(source=f"https://huggingface.co/{x['repo']}/resolve/{x['revision']}/{x['file']}",bytes=x['bytes'],sha256=x['sha256'])) for x in models]
assert sum(x['bytes'] for _,x in items)<1024**3
for name,item in items:
 target=cache/name;target.parent.mkdir(parents=True,exist_ok=True)
 if not target.exists():
  checksum=hashlib.sha256();count=0
  with urllib.request.urlopen(item['source'],timeout=90) as response,target.with_suffix(target.suffix+'.part').open('xb') as out:
   while block:=response.read(1024**2):
    count+=len(block);assert count<=item['bytes'],'size cap';checksum.update(block);out.write(block)
  assert count==item['bytes'] and checksum.hexdigest()==item['sha256'],name
  target.with_suffix(target.suffix+'.part').rename(target)
 assert target.stat().st_size==item['bytes'] and hashlib.file_digest(target.open('rb'),'sha256').hexdigest()==item['sha256'],name
 records.append(dict(item,path=name));print(name,item['bytes'],flush=True)
(root/'downloads.json').write_text(json.dumps({'totalBytes':sum(x['bytes'] for x in records),'capBytes':1024**3,'files':records},indent=2)+'\n')
if not (runtime/'bin/python3.12').exists():
 with tarfile.open(cache/'python.tar.gz') as tar:
  for member in tar.getmembers():
   member.name=member.name.removeprefix('python/')
   if member.name:tar.extract(member,runtime,filter='data')
for x in models:
 source=cache/x['repo'].replace('/','--')/x['file'];dest=runtime/'models'/x['repo'].replace('/','--')/x['file'];dest.parent.mkdir(parents=True,exist_ok=True)
 if not dest.exists():dest.write_bytes(source.read_bytes())
print(runtime,flush=True)
