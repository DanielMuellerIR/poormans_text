import Foundation
import XCTest
@testable import PoorMansTextCore
final class RuntimeQualificationTests: XCTestCase {
    func testExistingQualifiedReadOnlyRuntimeInventory() throws {
        let root = URL(fileURLWithPath: ProcessInfo.processInfo.environment["PMT_INVENTORY_RUNTIME"]!)
        let data = try Data(contentsOf: root.appendingPathComponent("runtime-manifest.json"))
        let hash = ConversionFileFingerprint.digest(data)
        XCTAssertEqual(hash, "cd4673de443d7e2570d6c4c4666cecb4924e2ceaf22703cba2a273a544eface6")
        let value = try JSONSerialization.jsonObject(with: data) as! [String: Any]
        let values = value["files"] as! [String: [String: Any]]
        let files = values.mapValues { LinuxStructuredOCR.RuntimeFile(sha256: $0["sha256"] as! String, byteCount: $0["byteCount"] as! Int) }
        XCTAssertNoThrow(try LinuxStructuredOCR.validateInventory(root, files: files,
            manifest: .init(sha256: hash, byteCount: data.count)))
    }
}
