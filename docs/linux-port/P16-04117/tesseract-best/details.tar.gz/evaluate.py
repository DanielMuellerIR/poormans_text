import pathlib,json,unicodedata,re,collections,difflib,importlib.util,hashlib
r=pathlib.Path('/tmp/pmt-best-models-20261105');w=r/'work';spec=importlib.util.spec_from_file_location('quality','/home/dm/git/poormans_text/scripts/linux-probes/p11/docling/quality.py');q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)
refs=json.load(open('/home/dm/git/poormans_text/docs/linux-port/P11-NATURAL-EVIDENCE/selected-reference.json'));runs={(x['case'],x['variant']):x for x in json.loads((w/'runs.json').read_text())};typed=json.loads((r/'typed-results.json').read_text());assert len(typed)==14
expectedCells=[dict(row=a,column=b,rowspan=1,colspan=c-b+1,text=t) for a,b,c,t in [(0,0,1,'MERGED HEADER'),(0,2,2,'TOTAL'),(1,0,0,'A1'),(1,1,1,'B1'),(1,2,2,'C1'),(2,0,0,'A2'),(2,1,1,'B2'),(2,2,2,'C2')]]
synthetic='STRUCTURED DOCUMENT\nLEFT ALPHA paragraph\nLEFT BETA paragraph\nRIGHT GAMMA paragraph\nRIGHT DELTA paragraph\n1. First list item\n2. Second list item\n'+'\n'.join(c['text'] for c in expectedCells)
mixed='\n'.join(['Invoice ALPHA 12345','Die Rechnung kostet 42 Euro.','Grüße aus München und schöne Grüße.','The quick brown fox jumps over the lazy dog.']+['Rotation sentinel ALPHA 12345']*5)
def words(s):return collections.Counter(re.findall(r'\w+',unicodedata.normalize('NFC',s).casefold()))
def authority(d):return '\n'.join([x['orig'] for x in d['texts']]+[c['text'] for t in d['tables'] for c in t['data']['table_cells']])
def tables(d):return [[dict(row=c['start_row_offset_idx'],column=c['start_col_offset_idx'],rowspan=c['row_span'],colspan=c['col_span'],text=c['text']) for c in t['data']['table_cells']] for t in d['tables']]
def expand(c):return sorted(c.elements())
results=[]
for name in ['structured','nodpi','natural132','natural134','natural135','mixed','standard-mixed']:
 expectedTables=[]
 if name in ['structured','nodpi']:expected=synthetic;expectedTables=[expectedCells]
 elif name in ['mixed','standard-mixed']:expected=mixed
 else:
  elements=refs['01030000000'+name[-3:]+'.pdf']['elements'];chunks=[]
  for e in elements:
   if e['category']=='Table':
    p=q.Cells();p.feed(e['content']['html']);expectedTables.append(p.cells);chunks.extend(c['text'] for c in p.cells)
   else:chunks.append(e['content']['text'])
  expected='\n'.join(chunks)
 target=words(expected);values={};raw={}
 for variant in ['base','best']:
  if name=='standard-mixed':text=(w/'results'/('standard-'+variant+'.txt')).read_text();pt=[];run=next(x for x in json.loads((w/'standard-runs.json').read_text()) if x['variant']==variant)
  else:
   d=json.loads((w/'results'/(name+'-'+variant+'.json')).read_text());text=authority(d);pt=tables(d);run=runs[name,variant]
  raw[variant]=text;observed=words(text);missing=target-observed;extra=observed-target
  values[variant]=dict(expectedWords=sum(target.values()),observedWords=sum(observed.values()),missingCount=sum(missing.values()),extraCount=sum(extra.values()),missing=expand(missing),extra=expand(extra),predictedTableCount=len(pt),expectedTableCount=len(expectedTables),tableMetrics=q.measure(expectedTables[0],pt[0]) if len(expectedTables)==len(pt)==1 else None,seconds=run['seconds'],peakKiB=run['peakKiB'],typed=next(x for x in typed if x['case']==name and x['variant']==variant))
 a,b=values['base'],values['best'];delta=dict(recoveredMissing=expand(collections.Counter(a['missing'])-collections.Counter(b['missing'])),newlyMissing=expand(collections.Counter(b['missing'])-collections.Counter(a['missing'])),removedExtras=expand(collections.Counter(a['extra'])-collections.Counter(b['extra'])),newExtras=expand(collections.Counter(b['extra'])-collections.Counter(a['extra'])))
 positive=bool(delta['recoveredMissing'] or delta['removedExtras']);negative=bool(delta['newlyMissing'] or delta['newExtras']);classification='mixed' if positive and negative else 'improvement' if positive else 'regression' if negative else 'same-token-inventory'
 diff=''.join(difflib.unified_diff(raw['base'].splitlines(True),raw['best'].splitlines(True),fromfile=name+'-base',tofile=name+'-best'));(r/'delivery'/(name+'-diff.txt')).write_text(diff)
 results.append(dict(case=name,classification=classification,base=a,best=b,delta=delta))
(r/'comparison.json').write_text(json.dumps(dict(tokenization='NFC Unicode w+ casefold, exact multiplicities; no accent/linebreak/spelling repairs',referenceFiles=['selected-reference.json','original synthetic eight-cell reference','existing mixed fixture generation strings'],cases=results),ensure_ascii=False,indent=2)+'\n')
print(json.dumps([dict(case=x['case'],classification=x['classification'],base=(x['base']['missingCount'],x['base']['extraCount']),best=(x['best']['missingCount'],x['best']['extraCount']),delta=x['delta']) for x in results],ensure_ascii=False,indent=2))
