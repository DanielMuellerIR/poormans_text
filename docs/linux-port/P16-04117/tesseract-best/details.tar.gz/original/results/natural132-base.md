|  |  |
| --- | --- |
| Fish species on IUCN Red List |  |
| Potosi Pupfish | Cyprinodon alvarezi |
| La Palma Pupfish | Cyprinodon longidorsalis |
| Butterfly Splitfin | Ameca splendens |
| Golden Skiffia | Skiffia francesae |

Table 6.1: Four fish species on IUCN Red List "Extinct in the Wild" held in public aquariums.

Public aquariums, because of their inhouse expertise, can act quickly to collect and breed rare fish. Actions to prevent the extinction of the Barrens Topminnow include monitoring populations and propagating and stocking juveniles into existing or newly created spring habitats. The Tennessee Aquarium assisted with propagations and developed a program called "Keeper Kids," where students on spring break help feed the Barrens Topminnows in a\_ behind-the-scenes experience.

Figure 6.3: Photo of the critically endangered Butterfly Splitfin (Ameca spendens).

The breeding colonies of the Butterfly Splitfin (Figure 6.3) at the London Zoo and elsewhere serve as ark populations essential to the survival of this species. Butterfly Splitfins are endemic to the Rio Ameca in western Mexico and almost extinct in the wild. Actions such as nonnative fish removal, stream restoration, and sanctuary designation may take decades before eventual introduction and survival in the wild. The Tennessee Aquarium is part of a large partnership to guide hatchery augmentation and recovery of the rarest darter in North America (U.S. Fish and Wildlife Service 2019). The Conasauga Logperch (Percina jenkinsi), a federally endangered darter (Percidae), is found only in a 30-mile (48 km) stretch of the Conasauga River in Georgia and Tennessee (Moyer et al. 2015).

Figure 6.4: Lake Sturgeon (Acipenser fulvescens).

\|

The Banggai Cardinalfish (Pterapogon kauderni), a small, endangered tropical cardinalfish in the family Apogonidae, is now bred and displayed in numerous public aquariums after overharvest in the wild drove wild populations to near extinction. Consequently, most Banggai Cardinalfish sold to hobbyists in the United States and European Union today are captive bred.

132

Public Aquariums and Their Role in Education, Science, and Conservation