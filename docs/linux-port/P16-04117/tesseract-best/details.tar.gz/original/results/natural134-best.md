What's unique about the growth of Alligator Gars is their fast growth in the first years of life followed by slower growth (Figure 8.6; Figure 8.7). Juvenile Alligator Gars quickly transition to fish-eating habits (Butler et al. 2018). A fish diet means the juveniles grow at 4-5 mm per day in the first three months of life, so that by the end of the first growing season they may reach 1.5 to 2 feet in length (\~40-70 cm) and 8-10 pounds in weight (Sakaris et al. 2019). Despite their fast growth, young Alligator Gars are preyed upon by many larger fish.

Figure 8.6: Growth in length of Alligator Gar in Texas. Figure 8.7: Growth in weight of Alligator Gar in Texas. Long description.

120

1

300

100

\|

250

80

\|

200

60

\|

150

Length

{cm

and

in)

40

\|

100

20

50

Length

of

Gar

Fish

by

Age

10

20

30

40

50

60

70

RO

90

Age

(years)

Figure 8.7: Growth in weight of Alligator Gar in Texas.

Ibs

kg

140

300

120

250

100

200

LE

80

ET

oE

150

Fg

60

001

S04

20

ol

©

Weight

of

Gar

Fish

by

Age

Texas

rod

\&

reel

record

alligator

gar

(279

Lbs)

0

20

30

an

50

60

i)

80

0

Age

(years)

Angling and Conservation of Living Fishy Dinosaurs \| 171