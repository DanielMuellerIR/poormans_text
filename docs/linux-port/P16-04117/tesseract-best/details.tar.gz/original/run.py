import os,sys,json,time,subprocess,pathlib,hashlib
root=pathlib.Path('/work');results=[];inputs=json.loads((root/'inputs.json').read_text());started=time.monotonic()
for name in ['structured','nodpi','natural132','natural134','natural135','mixed']:
 for variant in ['base','best']:
  dst=root/'results'/(name+'-'+variant+'.json');assert not dst.exists();env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','HOME':'/tmp','TMPDIR':'/tmp'}
  if variant=='best':env['TESSDATA_PREFIX']='/models'
  langs=['deu','eng'] if name=='mixed' else ['eng'];err=root/'results'/(name+'-'+variant+'.stderr');begin=time.monotonic();peak={}
  with err.open('w') as errors:
   child=subprocess.Popen(['/runtime/bin/python3.12','-I','/work/worker.py','/runtime','/inputs/'+name+'.png',json.dumps(langs),str(dst)],env=env,stdout=subprocess.PIPE,stderr=errors)
   while child.poll() is None and time.monotonic()-begin<100:
    try:
     for line in pathlib.Path(f'/proc/{child.pid}/status').read_text().splitlines():
      if ':' in line:
       k,v=line.split(':',1)
       if k in ['VmPeak','VmSize','VmHWM','VmRSS']:peak[k]=max(peak.get(k,0),int(v.strip().split()[0]))
    except FileNotFoundError:pass
    time.sleep(.02)
   if child.poll() is None:child.terminate()
   out,_=child.communicate(timeout=5)
  record=dict(case=name,variant=variant,exit=child.returncode,seconds=time.monotonic()-begin,peakKiB=peak,stdout=out.decode(errors='replace'),stderr=err.read_text()[-2048:],languages=langs)
  if child.returncode==0:
   binding=json.loads(out);assert binding['sourceSHA256']==inputs[name+'.png']['sha256'];assert binding['documentSHA256']==hashlib.sha256(dst.read_bytes()).hexdigest();record['bindingVerified']=True
  results.append(record);(root/'runs.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k not in ['stdout','stderr']}),flush=True)
assert time.monotonic()-started<1200
