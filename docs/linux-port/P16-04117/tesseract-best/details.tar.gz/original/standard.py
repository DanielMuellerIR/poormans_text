import pathlib,subprocess,time,os,json,resource
resource.setrlimit(resource.RLIMIT_AS,(4*1024**3,)*2);resource.setrlimit(resource.RLIMIT_CPU,(120,)*2)
r=pathlib.Path('/work');out=[]
for variant in ['base','best']:
 env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','OMP_NUM_THREADS':'2'}
 if variant=='best':env['TESSDATA_PREFIX']='/models'
 start=time.monotonic();peak={};p=subprocess.Popen(['/usr/bin/tesseract','/inputs/mixed.png','stdout','-l','deu+eng','--psm','1','tsv'],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 while p.poll() is None and time.monotonic()-start<45:
  try:
   for row in pathlib.Path(f'/proc/{p.pid}/status').read_text().splitlines():
    if ':' in row:
     k,v=row.split(':',1)
     if k in ['VmPeak','VmSize','VmHWM','VmRSS']:peak[k]=max(peak.get(k,0),int(v.strip().split()[0]))
  except FileNotFoundError:pass
  time.sleep(.01)
 if p.poll() is None:p.terminate()
 stdout,stderr=p.communicate(timeout=5);(r/'results'/('standard-'+variant+'.tsv')).write_bytes(stdout);out.append(dict(variant=variant,exit=p.returncode,seconds=time.monotonic()-start,peakKiB=peak,stderr=stderr.decode(errors='replace')))
(r/'standard-runs.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
