import Foundation
@testable import PoorMansTextCore
let work = URL(fileURLWithPath: CommandLine.arguments[1])
let manifest = try JSONSerialization.jsonObject(with: Data(contentsOf: work.appendingPathComponent("inputs.json"))) as! [String: Any]
var records = [[String: Any]]()
for name in ["structured", "nodpi", "natural132", "natural134", "natural135", "mixed"] {
    for variant in ["base", "best"] {
        let file = name + "-" + variant
        var record: [String: Any] = ["case": name, "variant": variant]
        do {
            let data = try Data(contentsOf: work.appendingPathComponent("results/" + file + ".json"))
            let input = manifest[name + ".png"] as! [String: Any]
            let size = input["size"] as! [Int]
            let dpi = input["dpi"] as? [Double]
            let projected = try DoclingDocumentProjection.parse(data)
            let result = try LinuxStructuredOCR.project(data, width: size[0], height: size[1], dpiX: dpi?[0], dpiY: dpi?[1])
            let raw = try JSONSerialization.jsonObject(with: data) as! [String: Any]
            let texts = raw["texts"] as! [[String: Any]]
            let cells = (raw["tables"] as! [[String: Any]]).flatMap { ($0["data"] as! [String: Any])["table_cells"] as! [[String: Any]] }
            let authority = StructuredOCRRendering.inventory(texts.compactMap { $0["orig"] as? String } + cells.compactMap { $0["text"] as? String })
            let output = StructuredOCRRendering.inventory(result.page.blocks.map(\.text))
            guard authority == output, projected.rawCellCount == cells.count else { throw DoclingDocumentProjection.Failure(reason: "independent inventory mismatch") }
            try Data(result.page.markdown.utf8).write(to: work.appendingPathComponent("results/" + file + ".md"))
            record["ok"] = true
            record["cellCount"] = cells.count
            record["inventoryPreserved"] = true
            record["diagnostics"] = result.diagnostics.map(\.code)
        } catch {
            record["ok"] = false
            record["error"] = error.localizedDescription
        }
        records.append(record)
    }
}
for variant in ["base", "best"] {
    let text = try String(contentsOf: work.appendingPathComponent("results/standard-" + variant + ".tsv"), encoding: .utf8)
    do {
        let result = try LinuxOCR.parseTSV(text, width: 1600, height: 1100)
        let recognized = result.lines.map(\.recognized).joined(separator: "\n")
        try Data(recognized.utf8).write(to: work.appendingPathComponent("results/standard-" + variant + ".txt"))
        records.append(["case": "standard-mixed", "variant": variant, "ok": true, "lineCount": result.lines.count])
    } catch {
        records.append(["case": "standard-mixed", "variant": variant, "ok": false, "error": error.localizedDescription])
    }
}
print(String(decoding: try JSONSerialization.data(withJSONObject: records, options: [.prettyPrinted, .sortedKeys]), as: UTF8.self))
